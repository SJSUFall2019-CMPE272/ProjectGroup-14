const AMAZON = {
    clientID: "amzn1.application-oa2-client.8c69d80c4d3b441e95bb0dea68412103",
    clientSecret: "0670646811fceac12bce8eb45572a9f978e80b000818f1f4cf867cfe5e9d1c27"
};
const GITHUB = {
    clientID: "ca07c74962097b8480f6",
    clientSecret: "a9428e7a75c59e24a32c0f473da2dbd42d5fbb89"
};
const FACEBOOK = {
    clientID: "2503599789703821",
    clientSecret: "645088b310270cf3abbda58e01f65e96"
};
const GOOGLE = {
    clientID: "767059472934-s7s2rfm1ck3auiq620h2amls0d1rucs9.apps.googleusercontent.com",
    clientSecret: "NlNvTx6kCSq7B2_YLAog8jtG"
};
const INSTAGRAM = {
    clientID: "0d517fd22d63445181091e63578caf92",
    clientSecret: "3ea8588c8f7f43ebb4ff89fd5519b1fc"
};
const SPOTIFY = {
    clientID: "2ab04beb997b4e75bede51e1caed6ffc",
    clientSecret: "27d00d3b6dcb4ac2af1fa6f64cd0ce74"
};
const TWITCH = {
    clientID: "3bim2h9k5ht5jfyktqpuqiasdexg27",
    clientSecret: "bz4tt9sztacz4sd8qx8rg8imqbsjjn"
};

module.exports = {
    AMAZON,
    GITHUB,
    FACEBOOK,
    GOOGLE,
    INSTAGRAM,
    SPOTIFY,
    TWITCH
};